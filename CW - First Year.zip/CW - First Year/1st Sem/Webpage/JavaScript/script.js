/* External CSS linked for formvalidation to the Contact Page */

function formvalidation(){
  var fname = document.forms["messageform"]["fullname"].value;
  var mail = document.forms["messageform"]["emails"].value;
  var text = document.forms["messageform"]["message"].value;

  if(fname ==""){
    window.alert("Please enter your Full Name");
    return false;
  }

  if(mail ==""){
    window.alert("Please enter your Email");
    return false;
  }

  if(text ==""){
    window.alert("Please enter your Message");
    return false;
  }

  else{
    window.alert("Thank you for your feedback");
  }
}