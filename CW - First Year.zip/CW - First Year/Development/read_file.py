# Defining a function to read the details of a file and store it on a two-dimensional list
def read_txt_file():
    # Opening the file that lists the information about the bikes in reading mode
    file = open("bikes_list.txt", "r")
    # Use of readlines function in order to store the details of the bike on a list
    files = file.readlines();
    bike_list = []
    # Appending all the details of the bike on a new list to make it two-dimensional
    for line in files:
        bike_list.append(line.replace("\n", "").split(","))
    file.close()
    print("+--------------------------------------------------------------------------------------------------+")
    print("|\t\t        Bike Management System\t\t\t  |")
    print("+--------------------------------------------------------------------------------------------------+")
    print("|  Bike ID \t Name \t Manufacturer \tColor \tQuantity \t     Price       |")
    print("+--------------------------------------------------------------------------------------------------+")
    for i in range(len(bike_list)):
        print("|  " + str(bike_list[i][0]) + "\t" + str(bike_list[i][1]) + "\t" + str(bike_list[i][2]) + "\t" + str(
            bike_list[i][3]) + "\t    " + str(bike_list[i][4]) + "\t$" + str(bike_list[i][5]) + "  |")
    print("+--------------------------------------------------------------------------------------------------+")
    print()
    # Final statement to return the 2D list storing all the required information
    return bike_list

