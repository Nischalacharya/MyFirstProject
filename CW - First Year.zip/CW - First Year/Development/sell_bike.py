import re


# Defining a function to sell bikes from the system that accepts the passed 2D list of bikes as the parameter
def sell_bikes(listed_bikes):
    # Assigning the parameter list to the new variable and declaring an empty dictionary to store user's selling details
    bike_list = listed_bikes
    quantity_dictionary = {}
    amount_dictionary = {}

    # Use of a loop in order for the user to input their valid names
    while True:
        # Asking the user to input their names and checking through the regular expression if correct values are entered
        first_name = input("Enter your first name please: ")
        last_name = input("Enter your last name please: ")
        print()
        if not (re.match("^[a-zA-Z]*$", first_name) and re.match("^[a-zA-Z]*$", last_name)):
            print("Only alphabets are allowed while naming.")
        else:
            string_name = first_name + " " + last_name
            print(f"Hello {string_name}, we ask to be aware of the procedures while the bike is being purchased.")
            break

    # Use of while loop to iterate through the bike transaction till the user chooses to exit
    selling_bikes = True
    bike_added = False
    while selling_bikes:
        print()
        # Asking the user to input the bike code they wish to buy and examining for valid values entered
        bike_code = (input("Enter the code of the bike you wish to proceed to buy : ")).upper()
        # Iterating the code entered with every element's first index stored on the list
        for i in range(len(bike_list)):
            if bike_code == bike_list[i][0]:
                bike_added = True
                break

        if bike_added:
            # Use of while loop in order to continuously ask the user until correct values are entered
            while True:
                # Exception Handling to handle for any other values than integer
                try:
                    # Asking the user to input the number of bikes they want to buy
                    bike_quantity = int(input("Enter the number of bikes you wish to buy: "))
                    # Insertion of correct values for the examination process
                    if bike_quantity <= 0:
                        print("Please enter a positive integer value.")
                        print()
                        break
                    else:
                        break
                except:
                    print("Please enter an integer value.")
                    print()

            # Adding the quantity of bikes as the value and bike code as its key on the dictionary initialized
            for i in range(len(bike_list)):
                if bike_code == bike_list[i][0] and bike_quantity <= int(bike_list[i][4]):
                    quantity_dictionary[bike_code] = bike_quantity
                    break
                elif bike_quantity >= int(bike_list[i][4]):
                    print()
                    print(f"Sorry, the bike with ID {bike_code} does not have enough quantity for your purchase.")
                    break

        # Error message when an invalid book code has been entered
        else:
            print()
            print(f"Sorry, the bike with the ID {bike_code} hasn't been added on our store.")

        # Use of while loop in order to iterate through the user interface till a correct value is entered
        while True:
            print()
            # Asking the user if they'd wish to borrow any more books
            proceed_transaction = input("Do you wish to buy any more bikes (Y/N)? ").upper()
            # if yes loop through the top
            if proceed_transaction == "Y":
                selling_bikes = True
                break
            # if not, break the loop
            elif proceed_transaction == "N":
                selling_bikes = False
                break
            # if an invalid value is provided loop through it again
            else:
                print("Invalid input, try again.")
                continue

    # Calculation of the price to be paid and the grand total due
    print()
    total_amount = 0

    # Iterating through every elements stored on the dictionary and to calculate the amount of each bike and grand total
    for keys in quantity_dictionary.keys():
        for i in range(len(bike_list)):
            if keys == bike_list[i][0]:
                price = int(bike_list[i][5])
                quantity = int(quantity_dictionary[keys])
                amount_dictionary[keys] = price * quantity
                total_amount += amount_dictionary[keys]
                print(f"The total cost for the bike {bike_list[i][1]} is: $" + str(amount_dictionary[keys]))

    # Printing the output as the total amount or sum of all books as the grand total
    print(f"Hence, the total amount for all the bikes is: ${str(total_amount)}")
    print()

    # Creation of selling notice invoice for the bike transaction
    # Extraction of date and time to add on the txt file
    import datetime
    date_atm = str(datetime.datetime.now().year) + "-" + str(datetime.datetime.now().month) + "-" + str(
        datetime.datetime.now().day)
    time_atm = str(datetime.datetime.now().hour) + "-" + str(datetime.datetime.now().minute) + "-" + str(
        datetime.datetime.now().second)
    date_time = str(date_atm) + " " + str(time_atm)
    # File writing with the user's name, date and time and transaction made and other details
    file_write = open(string_name + " " + date_time + " (Sold).txt", "w")
    file_write.write(
        "---------------------------------------------------------- INVOICE -------------------------------------------------------")
    file_write.write("\n")
    file_write.write(
        "--------------------------------------------------------- SELL BIKES ------------------------------------------------------")
    file_write.write("\n")
    file_write.write("\n")
    file_write.write(f"\t Name of the Shipping Company: {str(string_name)} \t\t\t Date: {str(date_atm)} \t\t\t\t Time: {str(time_atm)}")
    file_write.write("\n")
    file_write.write(
        "--------------------------------------------------------------------------------------------------------------------------")
    file_write.write("\n")
    file_write.write("\t Bike ID\t\tName of the Bike\t\t Manufacturer\t\tColor\t\tQuantity\tUnit Price\t\t Total Price")
    file_write.write("\n")

    # Iterating through the keys of the dictionary to find out the total amount to be paid
    for keys in quantity_dictionary.keys():
        for i in range(len(bike_list)):
            if keys == bike_list[i][0]:
                file_write.write(str(f"\t  {str(keys)}\t\t\t{str(bike_list[i][1])}\t\t{str(bike_list[i][2])}\t\t{str(bike_list[i][3])}\t   {str(quantity_dictionary[keys])}\t\t ${str(bike_list[i][5])}\t\t ${amount_dictionary[keys]}"))
                file_write.write("\n")

    # Writing of the total amount, rate of discount allowed and the grand total to be paid with a final notice
    file_write.write(
        "--------------------------------------------------------------------------------------------------------------------------")
    file_write.write("\n")
    file_write.write(f"\t\t\t\t\t\t\t\t\t Total Amount: ${str(total_amount)}")
    file_write.write("\n")
    file_write.write(
        "--------------------------------------------------------- THANKYOU -------------------------------------------------------")
    file_write.close()

    # It returns the dictionary that stored the details of book code and quantity purchased
    return quantity_dictionary
