# Importing all the python files which include file handling, bike transaction and overwriting the txt files
import read_file
import buy_bike
import sell_bike
import overwrite_list
import datetime


def main_menu():
    # Display of the main menu interface after the program is executed
    print("+--------------------------------------------------------------------------------------------------+")
    print()
    print("\t\t    BIKE MANAGEMENT SYSTEM \n")
    print("\t\t        Today's Date: " + str(datetime.datetime.now().year) + "/" + str(
        datetime.datetime.now().month) + "/" + str(datetime.datetime.now().day))

    # Provide the user choices for their specific action
    while True:
        print()
        print("\t\t               MAIN MENU \n")
        print("\t                Press [1] to view all the available bikes.")
        print("\t                Press [2] to buy bikes for the store.")
        print("\t                Press [3] to sell bikes from the store.")
        print("\t                Press [4] to exit the library.")
        print()
        print("+--------------------------------------------------------------------------------------------------+")
        print()

        user_input = input("Enter the action you wish to perform: ")
        print()

        # Calling the function of file reading when the user wants to view all the available bikes to be sold or bought
        if user_input == "1":
            x = read_file.read_txt_file()
            print("+--------------------------------------------------------------------------------------------------+")

        # Calling the function of bike ordering when the user wants to order any of the available bikes
        elif user_input == "2":
            # Calling the function of file reading to display all the bikes available for purchase
            x = read_file.read_txt_file()
            # Passing of the returned list from the bike read file on the purchasing book function
            y = buy_bike.buy_bikes(x)
            # Passing of the returned list and dictionary from the bike read file and bike sales function respectively to overwrite the txt file
            overwrite_list.over_write_buy(x, y)
            print()
            # Ask the user to if they'd wish to progress with another transaction or not
            ask_again = input("Do you wish to proceed for more transactions (Y/N)? ")
            print()
            print("+--------------------------------------------------------------------------------------------------+")
            if ask_again == "N":
                break

        # Calling the function of bike selling when the user wants to sell any of the available bikes
        elif user_input == "3":
            # Calling the function of file reading to display all the bikes available for purchase
            x = read_file.read_txt_file()
            # Passing of the returned list from the bike read file on the selling book function
            y = sell_bike.sell_bikes(x)
            # Passing of the returned list and dictionary from the bike read file and bike sales function respectively to overwrite the txt file
            overwrite_list.over_write_sell(x, y)
            print()
            # Ask the user to if they'd wish to progress with another transaction or not
            ask_again = input("Do you wish to proceed for more transactions (Y/N)? ")
            print()
            print("+--------------------------------------------------------------------------------------------------+")
            if ask_again == "N":
                break

        # Terminating the loop once the user completes their task
        elif user_input == "4":
            print("Have a nice day ahead.")
            break

        # For an invalid value entered and then loop throughout till a valid input is entered
        else:
            print("Invalid input.")
            print()
            print("+--------------------------------------------------------------------------------------------------+")


main_menu()
