# Defining a function to overwrite the txt file which accepts the list and dictionary as its parameters
def over_write_buy(listed_bikes, dictionary_items):
    # Assigning the returned list from bike read file to a new variable
    list_data = listed_bikes
    # Assigning the returned dictionary from bought notice of bikes to a new variable
    dictionary_data = dictionary_items

    # Examining the index of the list and then adding to its respective key of the dictionary
    for keys in dictionary_data.keys():
        for i in range(len(list_data)):
            if keys == list_data[i][0]:
                list_data[i][4] = str(int(list_data[i][4]) + int(dictionary_data[keys]))

    # Displaying of the new updated list after increasing the amount of bike stocks
    print("The new updated list is as follows: ")
    for items in list_data:
        print(items)

    # File writing to update the quantity of the bike stock after ordering
    files = open("bikes_List.txt", "w")
    for elements in list_data:
        files.write(str(",".join(elements)))
        files.write("\n")
    files.close()
    return


# Defining a function to overwrite the txt file which accepts the list and dictionary as its parameters
def over_write_sell(listed_bikes, dictionary_items):
    # Assigning the returned list from bike read file to a new variable
    list_data = listed_bikes
    # Assigning the returned dictionary from sold notice of bikes to a new variable
    dictionary_data = dictionary_items

    # Examining the index of the list and then subtracting from its respective key of the dictionary
    for keys in dictionary_data.keys():
        for i in range(len(list_data)):
            if keys == list_data[i][0]:
                list_data[i][4] = str(int(list_data[i][4]) - int(dictionary_data[keys]))

    # Displaying of the new updated list after reducing the amount of bike stocks
    print("The new updated list is as follows: ")
    for items in list_data:
        print(items)

    # File writing to update the quantity of the bike stock after selling
    files = open("bikes_List.txt", "w")
    for elements in list_data:
        files.write(str(",".join(elements)))
        files.write("\n")
    files.close()
    return
